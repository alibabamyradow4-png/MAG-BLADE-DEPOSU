import 'package:flutter/material.dart';

class PhoneHomeScreen extends StatefulWidget {
  const PhoneHomeScreen({Key? key}) : super(key: key);

  @override
  State<PhoneHomeScreen> createState() => _PhoneHomeScreenState();
}

class _PhoneHomeScreenState extends State<PhoneHomeScreen> {
  final List<Map<String, dynamic>> apps = [
    {'name': 'MIA VPN', 'icon': Icons.vpn_key, 'color': Colors.teal},
    {'name': 'JUMP VPN', 'icon': Icons.security, 'color': Colors.purple},
    {'name': 'ChatGPT', 'icon': Icons.chat, 'color': Colors.green},
    {'name': 'SHAREit', 'icon': Icons.share, 'color': Colors.blue},
    {'name': 'Play Store', 'icon': Icons.play_arrow, 'color': Colors.redAccent},
    {'name': 'YouTube', 'icon': Icons.video_library, 'color': Colors.red},
    {'name': 'Chrome', 'icon': Icons.public, 'color': Colors.amber},
    {'name': 'Ayarlar', 'icon': Icons.settings, 'color': Colors.blueGrey},
    {'name': 'Dosyalar', 'icon': Icons.folder, 'color': Colors.orange},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 10.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.between,
                children: [
                  Row(
                    children: [
                      const Text(
                        'MAG ',
                        style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white),
                      ),
                      Text(
                        'STUDIO',
                        style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold, color: const Color(0xFFFF007F)),
                      ),
                    ],
                  ),
                  IconButton(
                    icon: const Icon(Icons.settings_outlined, color: Colors.white70),
                    onPressed: () {},
                  ),
                ],
              ),
              const SizedBox(height: 20),
              Expanded(
                child: GridView.builder(
                  itemCount: apps.length,
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 3,
                    crossAxisSpacing: 12,
                    mainAxisSpacing: 16,
                    childAspectRatio: 0.85,
                  ),
                  itemBuilder: (context, index) {
                    final app = apps[index];
                    bool isFirst = index == 0;

                    return Column(
                      children: [
                        Container(
                          height: 75,
                          width: 75,
                          decoration: BoxDecoration(
                            color: const Color(0xFF161622),
                            borderRadius: BorderRadius.circular(20),
                            border: Border.all(
                              color: isFirst ? const Color(0xFF00FFFF) : Colors.white.withOpacity(0.08),
                              width: isFirst ? 2 : 1,
                            ),
                            boxShadow: isFirst
                                ? [
                                    BoxShadow(
                                      color: const Color(0xFF00FFFF).withOpacity(0.3),
                                      blurRadius: 8,
                                      spreadRadius: 1,
                                    )
                                  ]
                                : [],
                          ),
                          child: Icon(app['icon'], size: 34, color: app['color']),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          app['name'],
                          style: const TextStyle(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w500),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    );
                  },
                ),
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(width: 8, height: 8, decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle)),
                  const SizedBox(width: 6),
                  Container(width: 6, height: 6, decoration: BoxDecoration(color: Colors.white.withOpacity(0.3), shape: BoxShape.circle)),
                  const SizedBox(width: 6),
                  Container(width: 6, height: 6, decoration: BoxDecoration(color: Colors.white.withOpacity(0.3), shape: BoxShape.circle)),
                ],
              ),
              const SizedBox(height: 10),
            ],
          ),
        ),
      ),
    );
  }
}