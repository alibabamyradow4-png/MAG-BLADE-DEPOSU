import 'package:flutter/material.dart';
import 'home_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(seconds: 3), () {
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const PhoneHomeScreen()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'MAG STUDIO',
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                letterSpacing: 2,
                foreground: Paint()
                  ..shader = const LinearGradient(
                    colors: [Color(0xFF00FFFF), Color(0xFFFF007F)],
                  ).createShader(const Rect.fromLTWH(0.0, 0.0, 300.0, 70.0)),
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'MAG STUDIO LAUNCHER',
              style: TextStyle(color: Colors.purpleAccent, letterSpacing: 1.5, fontSize: 14),
            ),
            const SizedBox(height: 60),
            const Text('Loading...', style: TextStyle(color: Colors.grey)),
            const SizedBox(height: 15),
            SizedBox(
              width: 250,
              child: LinearProgressIndicator(
                backgroundColor: Colors.white12,
                color: const Color(0xFFFF007F),
                minHeight: 6,
              ),
            ),
          ],
        ),
      ),
    );
  }
}